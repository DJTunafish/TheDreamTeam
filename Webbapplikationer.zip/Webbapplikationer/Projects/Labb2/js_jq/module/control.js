/*

    This is the control part connecting the table module and the page

*/
// Function run when DOM is finished loading (= document.ready() )
$(function() {

    // Connecting eventhandlers to elements, jQuery style

    // TODO
    //new table
    control.table = new Table();
    //bind create button with click, do anon fun with createtable in it
    $("#create").on("click", control.createTable);
    $("#edit").on("click", control.editTable);
});

// Dummy data
var data = "The Document Object Model (DOM) is a programming interface for" +
"HTML, XML and SVG documents. It provides a structured representation of the" + " document as a tree. The DOM defines methods that allow access to the tree," + " so that they can change the document structure, style and content.";

// Singleton control object, using immediate invoke pattern
// Control interaction between DOM and table module.
// Only use jQuery DOM API
var control = (function() {

    table : null;

    return {createTable: function() {
            var rows = $("#rows").val();
            var cols = $("#cols").val();
            var stripes = $("#striped").is(':checked');
            table = new Table(parseInt(rows), parseInt(cols), data, stripes);
            var tbl = table.render();
            tbl.id = "table";
            if ($("#table").length == 0) {

              console.log("no table, appending one");
              $("#parent").append(tbl);
            }
            else {
              $("#table").remove();
              tbl.id = "table";
              $("#parent").append(tbl);
            }


        }, editTable: function() {
          if( table != null){
            var row = $("#row").val();
            var col = $("#col").val();
            var v = $("#value").val();
            table.edit(row, col, v);
          }
        }}
})();
